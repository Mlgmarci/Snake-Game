import random
import pygame
import os
import importlib

Buttons = importlib.import_module("Buttons")

pygame.init()

screen_info = pygame.display.Info()
bildschirm = pygame.display.set_mode((screen_info.current_w, screen_info.current_h), pygame.FULLSCREEN)
Game = pygame.Surface((screen_info.current_w, screen_info.current_h))
pygame.display.set_caption("Snake")

# Icons finden
ordner = os.path.dirname(os.path.abspath(__file__))
bilder_ordner = os.path.join(ordner, "Bilder")

# Icon laden
icon_path = os.path.join(bilder_ordner, "icon.png")
icon = pygame.image.load(icon_path)
pygame.display.set_icon(icon)

# Button-Bilder laden
beenden_button_pic = pygame.image.load(os.path.join(bilder_ordner, "beenden_hover.png")).convert_alpha()
einstellungen_button_pic = pygame.image.load(os.path.join(bilder_ordner, "einstellungen_hover.png")).convert_alpha()
start_button_pic = pygame.image.load(os.path.join(bilder_ordner, "start_hover.png")).convert_alpha()

# Mitte des Bildschirms berechnen
button_width = start_button_pic.get_width() * 1.5
button_height = start_button_pic.get_height() * 1.5
button_x = screen_info.current_w // 2 - button_width // 2
button_y = screen_info.current_h // 2 - button_height // 2

# Button-Objekte erstellen
start_button = Buttons.Button(button_x, 276, start_button_pic, 1.5)
einstellungen_button = Buttons.Button(button_x,button_y,einstellungen_button_pic, 1.5)
beenden_button = Buttons.Button(button_x, 672,beenden_button_pic, 1.5)



font = pygame.font.SysFont("arialblack", 80)  # Schriftart und Größe
text_farbe = (255, 255, 255)  # Weiß

def draw_text(text, font, text_farbe, v, b):
    text_surface = font.render(text, True, text_farbe)
    bildschirm.blit(text_surface, (v, b))

# Spielzustände
main_menu = "main"
Pause = True
Spiel = True


running = False
# Farbe
blau = (30, 30, 150)

# Spielfeld
zellgroesse = 20
spielfeld_breite = 600
spielfeld_hoehe = 600
feld_x = (screen_info.current_w - spielfeld_breite) // 2
feld_y = (screen_info.current_h - spielfeld_hoehe) // 2

mitte_spalte = (spielfeld_breite // zellgroesse) // 2
mitte_zeile = (spielfeld_hoehe // zellgroesse) // 2
x = feld_x + mitte_spalte * zellgroesse 
y = feld_y + mitte_zeile * zellgroesse 

# Fruchtrandomizer
frucht_spalte = random.randint(0, (spielfeld_breite // zellgroesse) - 1)
frucht_zeile = random.randint(0, (spielfeld_hoehe // zellgroesse) - 1)
frucht_x = feld_x + frucht_spalte * zellgroesse
frucht_y = feld_y + frucht_zeile * zellgroesse

hell = (120, 168, 60)
dunkel = (112, 156, 54)


# Hauptschleife
while Spiel:

    # Hintergrundfarbe
    bildschirm.fill((0, 0, 0, 255))
    if Pause == True:
            # Menüs
            if main_menu == "main":
                draw_text("Snake", font, text_farbe , 825, 100)
                if start_button.draw(bildschirm):
                    main_menu = "game"
                    Pause = False
                if einstellungen_button.draw(bildschirm):
                    main_menu = "settings"
                if beenden_button.draw(bildschirm):
                    Spiel = False
    else:
        
        Game.fill(blau)

        # Spiefeld
        for spalte in range(30):
            for zeile in range(30):
                pos_x = feld_x + spalte * zellgroesse
                pos_y = feld_y + zeile * zellgroesse
        
                if (spalte + zeile) % 2 == 0:
                    farbe = hell
                else:
                    farbe = dunkel

                pygame.draw.rect(Game, farbe, (pos_x, pos_y, zellgroesse, zellgroesse))

        # Snake
        pygame.draw.rect(Game, (255, 255, 255), (int(x), int(y), 20, 20)) 

        # Fruchtrandomizer
        pygame.draw.circle(Game, (255, 0, 0), (int(frucht_x + zellgroesse // 2), int(frucht_y + zellgroesse // 2)), 10)
        if pygame.Rect(x, y, 20, 20).colliderect(pygame.Rect(frucht_x, frucht_y, 20, 20)):
            frucht_spalte = random.randint(0, (spielfeld_breite // zellgroesse) - 1)
            frucht_zeile = random.randint(0, (spielfeld_hoehe // zellgroesse) - 1)
            frucht_x = feld_x + frucht_spalte * zellgroesse
            frucht_y = feld_y + frucht_zeile * zellgroesse
        
        # Bewegung der Schlange 
        if pygame.key.get_pressed() [pygame.K_LEFT]: 
            running = True
            if running == True:
                x = x - 20
        elif pygame.key.get_pressed() [pygame.K_RIGHT]: 
            running = True
            if running == True:
                x = x + 20
        elif pygame.key.get_pressed() [pygame.K_UP]:
            running = True
            if running == True:
                y = y - 20
        elif pygame.key.get_pressed() [pygame.K_DOWN]:
            running = True
            if running == True:
                y = y + 20
            
        # Bildschirmgrenzen überprüfen
        if x > screen_info.current_w:
            x = 0
        elif x < 0:
                x = screen_info.current_w
        if y > screen_info.current_h:
            y = 0
        elif y < 0:
            y = screen_info.current_h

            
            
        bildschirm.blit(Game, (0, 0))


    # Events abfragen (z.B. Fenster schließen)
    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                    Pause = True
                    main_menu = "main"
        if event.type == pygame.QUIT:
                Spiel = False
            
    # Alles anzeigen
        
    pygame.display.flip()

    # FPS
    uhr = pygame.time.Clock()
    uhr.tick(60)

pygame.quit()